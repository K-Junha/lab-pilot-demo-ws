@echo off
title LAB Pilot - Start All Servers
echo ============================================
echo   LAB Pilot - Starting All Servers
echo ============================================
echo.

:: Python executable
set PYTHON=C:\Users\ROADLAB_IPC\miniconda3\envs\sila2_env\python.exe
set MAT_NAV=%~dp0mat_nav_lib

:: 1) Backend (FastAPI)
echo [1/3] Starting Backend (FastAPI :8000) ...
start "LAB Pilot - Backend" cmd /k "cd /d %~dp0lab-pilot-demo\backend && set PYTHONPATH=%MAT_NAV% && %PYTHON% -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload"
timeout /t 2 /nobreak >nul

:: 2) Balance SiLA Server
echo [2/3] Starting Balance SiLA Server (:50051) ...
start "LAB Pilot - Balance SiLA" cmd /k "cd /d %~dp0ss_manager\balance && %PYTHON% balance_server.py --com COM11 --port 50051"
timeout /t 2 /nobreak >nul

:: 3) Frontend (Quasar dev)
echo [3/3] Starting Frontend (Quasar :9000) ...
start "LAB Pilot - Frontend" cmd /k "cd /d %~dp0lab-pilot-demo\frontend && pnpm dev"

echo.
echo ============================================
echo   All servers started!
echo.
echo   Frontend:  http://localhost:9000
echo   Backend:   http://localhost:8000
echo   Balance:   localhost:50051 (SiLA)
echo ============================================
echo.
echo Press any key to close this launcher window...
pause >nul
