@echo off
title LAB Pilot - Stop All Servers
echo ============================================
echo   LAB Pilot - Stopping All Servers
echo ============================================
echo.

:: Kill by port (process tree to ensure child processes are also terminated)
echo Stopping Backend (port 8000) ...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":8000 " ^| findstr "LISTENING"') do taskkill /pid %%a /t /f >nul 2>&1

echo Stopping Balance SiLA Server (port 50051) ...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":50051 " ^| findstr "LISTENING"') do taskkill /pid %%a /t /f >nul 2>&1

:: Quasar dev server uses 9000 by default, falls back to 9001/9002/9003 if occupied
echo Stopping Frontend (ports 9000-9003) ...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":9000 " ^| findstr "LISTENING"') do taskkill /pid %%a /t /f >nul 2>&1
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":9001 " ^| findstr "LISTENING"') do taskkill /pid %%a /t /f >nul 2>&1
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":9002 " ^| findstr "LISTENING"') do taskkill /pid %%a /t /f >nul 2>&1
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":9003 " ^| findstr "LISTENING"') do taskkill /pid %%a /t /f >nul 2>&1

:: Kill all LAB Pilot cmd windows by matching command line (reliable, title-independent)
echo Closing all LAB Pilot server windows ...
powershell -NoProfile -Command "$demoPath = 'DEMO\lab-pilot-demo'; $silaPath = 'DEMO\ss_manager'; Get-CimInstance Win32_Process -Filter \"Name='cmd.exe'\" | Where-Object { $_.CommandLine -like \"*$demoPath*\" -or $_.CommandLine -like \"*$silaPath*\" -or $_.CommandLine -like '*start-all.bat*' -or $_.CommandLine -like '*stop-all.bat*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue; Write-Host \"Killed PID $($_.ProcessId)\" }"

echo.
echo ============================================
echo   All servers stopped.
echo ============================================
echo.
pause
